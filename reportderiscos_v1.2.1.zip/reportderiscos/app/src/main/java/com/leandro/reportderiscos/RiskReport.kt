package com.leandro.reportderiscos // ajuste se necessário

data class RiskReport(
    val title: String = "",
    val description: String = "",
    val location: String = "",
    val imageUrl: String = "",
    val userId: String = ""
)
