package com.leandro.reportderiscos

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // sempre direciona para a tela de login
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
