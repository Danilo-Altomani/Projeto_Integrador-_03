package com.leandro.reportderiscos

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.leandro.reportderiscos.databinding.ActivityMainBinding
import java.io.ByteArrayOutputStream

data class RiskReport(
    val description: String = "",
    val imageUrl: String = "",
    val userId: String = ""
)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private val auth by lazy { FirebaseAuth.getInstance() }
    private val dbRef by lazy { FirebaseDatabase.getInstance().reference.child("reports") }
    private val storageRef by lazy { FirebaseStorage.getInstance().reference.child("images") }

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == RESULT_OK) {
            val bmp = res.data?.extras?.get("data") as? Bitmap
            bmp?.let {
                binding.imageViewPhoto.setImageBitmap(it)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        binding.buttonTakePhoto.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            cameraLauncher.launch(intent)
        }

        binding.buttonSave.setOnClickListener {
            saveReport()
        }
    }

    private fun saveReport() {
        val desc = binding.editTextDescription.text.toString()
        val bmp = (binding.imageViewPhoto.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap

        if (desc.isBlank() || bmp == null) {
            Toast.makeText(this, "Adicione descrição e foto.", Toast.LENGTH_SHORT).show()
            return
        }

        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, baos)
        val data = baos.toByteArray()

        val imgRef = storageRef.child("${System.currentTimeMillis()}.jpg")
        imgRef.putBytes(data)
            .addOnSuccessListener {
                imgRef.downloadUrl.addOnSuccessListener { uri: Uri ->
                    val report = RiskReport(desc, uri.toString(), auth.uid ?: "")
                    dbRef.push().setValue(report)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Risco registrado com sucesso!", Toast.LENGTH_LONG).show()
                            binding.editTextDescription.text?.clear()
                            binding.imageViewPhoto.setImageResource(0)
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "Erro ao salvar no DB.", Toast.LENGTH_SHORT).show()
                        }
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Erro ao enviar imagem.", Toast.LENGTH_SHORT).show()
            }
    }
}
