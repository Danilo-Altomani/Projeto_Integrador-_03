package com.leandro.reportderiscos

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.*
import com.leandro.reportderiscos.databinding.ActivityReportsListBinding

class ReportsListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReportsListBinding
    private val dbRef by lazy { FirebaseDatabase.getInstance().reference.child("reports") }
    private val adapter by lazy { ReportsAdapter(listOf()) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportsListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        binding.recyclerViewReports.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewReports.adapter = adapter

        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = snapshot.children.mapNotNull { it.getValue(RiskReport::class.java) }
                adapter.updateList(list)
            }

            override fun onCancelled(error: DatabaseError) { }
        })
    }
}
